﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using UsingModels.Models;
using UsingModels.Controllers;

namespace UsingModels.Models
{
    public class SportsData
    {
        public static List<Details> GetData()
        {
            //List<Details> details = new List<Details>();
            Details ob = new Details
            {
                SportsPersonId=1,
                SportsPersonName="Srishti",
                SportsName="Mini Militia",
                DoesHeOrShePlaysNow=true

            };
            Details ob1 = new Details
            {
                SportsPersonId = 2,
                SportsPersonName = "sakshi",
                SportsName = "FIFA",
                DoesHeOrShePlaysNow = false

            };
            Details ob2 = new Details
            {
                SportsPersonId = 3,
                SportsPersonName = "Maahi",
                SportsName = "Temple Run",
                DoesHeOrShePlaysNow = false

            };
            Details ob3 = new Details
            {
                SportsPersonId = 4,
                SportsPersonName = "Swati",
                SportsName = "Pub G",
                DoesHeOrShePlaysNow = true

            };
            List<Details> data = new List<Details>();
            data.Add(ob);
            data.Add(ob1);
            data.Add(ob2);
            data.Add(ob3);

            return data;
        }


    }
}
