﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace UsingModels.Models
{
    public class Details
    {
        public int SportsPersonId { get; set; }
        public string SportsPersonName { get; set; }
        public string SportsName { get; set; }
        public Boolean DoesHeOrShePlaysNow { get; set; }
    }
}
